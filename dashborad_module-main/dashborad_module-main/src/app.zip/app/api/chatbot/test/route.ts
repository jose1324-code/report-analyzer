import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  try {
    // Test Ollama connection
    const response = await fetch('http://localhost:11434/api/tags');
    
    if (!response.ok) {
      return NextResponse.json({
        status: 'error',
        message: 'Ollama is not running or not accessible',
        suggestion: 'Start Ollama with: ollama serve'
      });
    }

    const data = await response.json();
    
    return NextResponse.json({
      status: 'success',
      message: 'Ollama is running',
      models: data.models || [],
      endpoint: 'http://localhost:11434'
    });

  } catch (error) {
    return NextResponse.json({
      status: 'error',
      message: 'Cannot connect to Ollama',
      error: error instanceof Error ? error.message : 'Unknown error',
      suggestion: 'Make sure Ollama is installed and running: ollama serve'
    });
  }
}
